<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

  public function __construct()
  {
    parent::__construct();
    
    if (!$this->session->userdata('logged_in')) {
      redirect('auth/login');
    }

    // Cek role admin
    if ($this->session->userdata('role') != 'A') {
      show_error('Akses ditolak. Halaman ini hanya untuk admin.');
    }
  }

  public function index()
  {
      $this->load->model('Laporan_model');
  
      $laporan_per_bulan = $this->Laporan_model->laporan_per_bulan();
  
      $data['labels'] = array_column($laporan_per_bulan, 'bulan');
      $data['jumlah'] = array_column($laporan_per_bulan, 'jumlah');
      $data['total_sudah'] = $this->Laporan_model->count_by_status('sudah');
      $data['total_belum'] = $this->Laporan_model->count_by_status('belum');

  
      $this->load->view('templates/header');
      $this->load->view('templates/top');
      $this->load->view('admin/dashboard', $data);
      $this->load->view('templates/footer');
  }
  

}
