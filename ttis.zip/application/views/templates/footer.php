  <!-- Footer -->
  <footer class="py-2 bg-primary mt-auto">
    <div class="container">
      <p class="m-0 text-center text-white">
        &copy; <?= date('Y') ?> TIM TANGGAP INSIDEN SIBER KABUPATEN MUARA ENIM
      </p>
    </div>
  </footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>